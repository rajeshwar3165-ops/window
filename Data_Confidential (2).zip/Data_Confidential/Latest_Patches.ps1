﻿$Server_List = Get-Content -Path C:\Users\higedelaadm\Desktop\servers.txt


Foreach ($Server in $Server_List)
{
    $Powershell_Session = New-PSSession -ComputerName $Server
    $Security_Update = Invoke-Command -Session $Powershell_Session {Get-HotFix}
    $Latest_Updates = $Security_Update | Sort-Object -Property InstalledOn -Descending | Select-Object -First 1
    $Latest_Updates
    Remove-PSSession $Powershell_Session
}



    